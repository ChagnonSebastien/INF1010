#include "Pouvoir.h"
#include <iostream>


Pouvoir::Pouvoir()
{
}

Pouvoir::Pouvoir(const Pouvoir& pouvoir) : nom_(pouvoir.obtenirNom()), 
	nombreDeDegat_(pouvoir.obtenirNombreDeDegat()),
	energieNecessaire_(pouvoir.obtenirEnergieNecessaire())
{

}

Pouvoir::Pouvoir(const std::string& nom, 
	unsigned int nombreDeDegat,	unsigned int energieNecessaire):
	nom_(nom), nombreDeDegat_(nombreDeDegat), 
	energieNecessaire_(energieNecessaire)
{
}

Pouvoir::~Pouvoir()
{
}

unsigned int Pouvoir::obtenirEnergieNecessaire() const
{
	return energieNecessaire_;
}

std::string Pouvoir::obtenirNom() const
{
	return nom_;
}

unsigned int Pouvoir::obtenirNombreDeDegat() const
{
	return nombreDeDegat_;
}

void Pouvoir::modifierNombreDeDegat(unsigned int nombreDegat)
{
	nombreDeDegat_ = nombreDegat;
}

void Pouvoir::modifierEnergieNecessarie(unsigned int energieNecessaire)
{
	energieNecessaire_ = energieNecessaire;
}

void Pouvoir::modifierNom(const std::string& nom)
{
	nom_ = nom;
}

void Pouvoir::operator=(const Pouvoir& pouvoir){

	nom_ = pouvoir.obtenirNom();
	nombreDeDegat_ = pouvoir.obtenirNombreDeDegat();
	energieNecessaire_ = pouvoir.obtenirEnergieNecessaire();

}

bool Pouvoir::operator==(const Pouvoir& pouvoir) const {

	return(nom_ == (pouvoir.obtenirNom()));

}

std::ostream & operator<<(std::ostream& o, const Pouvoir& pouvoir) {

	return o << pouvoir.obtenirNom() << " possede un nombre de degats de "
		<< pouvoir.obtenirNombreDeDegat() << " et une energie necessaire de " 
		<< pouvoir.obtenirEnergieNecessaire() << std::endl;
}